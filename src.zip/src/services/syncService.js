import Papa from 'papaparse';

/**
 * Converts a Google Sheets URL to a CSV export URL.
 * @param {string} url - The Google Sheets URL.
 * @returns {string} - The CSV export URL.
 */
const getCsvUrl = (url) => {
  if (!url) return '';
  // Match common Google Sheets URL patterns
  const match = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) {
    return `https://docs.google.com/spreadsheets/d/${match[1]}/export?format=csv`;
  }
  return url;
};

/**
 * Fetches and parses data from a Google Spreadsheet.
 * @param {string} url - The Google Sheets URL.
 * @returns {Promise<Array>} - A promise that resolves to the list of candidates.
 */
export const fetchSpreadsheetData = async (url) => {
  const csvUrl = getCsvUrl(url);
  
  return new Promise((resolve, reject) => {
    Papa.parse(csvUrl, {
      download: true,
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (results.errors.length > 0) {
          console.error('PapaParse Errors:', results.errors);
        }
        resolve(results.data);
      },
      error: (error) => {
        reject(error);
      }
    });
  });
};

/**
 * Synchronizes spreadsheet data with local storage and Domo (if configured).
 * @param {string} url - The Google Sheets URL.
 */
export const syncCandidates = async (url) => {
  try {
    const freshData = await fetchSpreadsheetData(url);
    
    // Get existing data from localStorage to preserve UI updates
    const existingCandidatesStr = localStorage.getItem('walkin_candidates');
    const existingCandidates = existingCandidatesStr ? JSON.parse(existingCandidatesStr) : [];
    
    // Merge logic: Prioritize Spreadsheet for identity columns, preserve UI columns if spreadsheet is empty for them
    const mergedData = freshData.map(newCand => {
      const existingCand = existingCandidates.find(c => String(c.ID) === String(newCand.ID));
      
      if (existingCand) {
        // Overlay standard spreadsheet columns on existing UI-updated data
        return {
          ...existingCand, // Keep existing UI updates (Orientation, GD Status, Aptitude, etc.)
          ...newCand,      // Overwrite with fresh Spreadsheet data (Identity columns)
          // Specifically ensure UI columns aren't wiped if spreadsheet column is empty
          'Orientation(Agree & Disagree)': newCand['Orientation(Agree & Disagree)'] || existingCand['Orientation(Agree & Disagree)'],
          'GD Status': newCand['GD Status'] || existingCand['GD Status'],
          'Aptitude SET': newCand['Aptitude SET'] || existingCand['Aptitude SET'],
          'Aptitude Marks': newCand['Aptitude Marks'] || existingCand['Aptitude Marks'],
          'Aptitude Status': newCand['Aptitude Status'] || existingCand['Aptitude Status'],
          'L1 Interviewer Name': newCand['L1 Interviewer Name'] || existingCand['L1 Interviewer Name'],
          'L1(selected /Rejected)': newCand['L1(selected /Rejected)'] || existingCand['L1(selected /Rejected)'],
          'L1 Comments': newCand['L1 Comments'] || existingCand['L1 Comments'],
          'L2 Interviewer Name': newCand['L2 Interviewer Name'] || existingCand['L2 Interviewer Name'],
          'L2(Selected /Rejected)': newCand['L2(Selected /Rejected)'] || existingCand['L2(Selected /Rejected)'],
          'L2Comments': newCand['L2Comments'] || existingCand['L2Comments'],
          'Final Role': newCand['Final Role'] || existingCand['Final Role'],
          'HR Round Status': newCand['HR Round Status'] || existingCand['HR Round Status'],
        };
      }
      return newCand;
    });

    localStorage.setItem('walkin_candidates', JSON.stringify(mergedData));
    localStorage.setItem('walkin_sheet_url', url);
    return mergedData;
  } catch (error) {
    console.error('Sync failed:', error);
    throw error;
  }
};

/**
 * Pushes candidate updates back to the Google Spreadsheet via Apps Script Web App.
 * @param {string} scriptUrl - The Apps Script Web App URL.
 * @param {Object|Array} data - The candidate data to sync.
 * @returns {Promise<Object>} - The response from the script.
 */
export const pushToGoogleSheet = async (scriptUrl, data) => {
  if (!scriptUrl) throw new Error("No Script URL provided");
  
  try {
    const response = await fetch(scriptUrl, {
      method: "POST",
      mode: "no-cors", // Required for Google Apps Script Web Apps
      cache: "no-cache",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(Array.isArray(data) ? data : [data]),
    });
    
    // With no-cors, we can't read the response body, but we can assume success if no error is thrown
    return { status: "success", msg: "Data pushed to sync engine" };
  } catch (error) {
    console.error("Push to Google Sheet failed:", error);
    throw error;
  }
};

/**
 * Updates a specific candidate in the local store and optionally pushes to cloud.
 * @param {string} id - The Candidate ID.
 * @param {Object} updates - The fields to update.
 */
export const updateCandidateLocally = (id, updates) => {
  const existingCandidatesStr = localStorage.getItem('walkin_candidates');
  if (!existingCandidatesStr) return;
  
  const candidates = JSON.parse(existingCandidatesStr);
  const updatedCandidates = candidates.map(c => {
    if (String(c.ID) === String(id)) {
      return { ...c, ...updates };
    }
    return c;
  });
  
  localStorage.setItem('walkin_candidates', JSON.stringify(updatedCandidates));
  return updatedCandidates;
};
