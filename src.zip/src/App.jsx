import { HashRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./components/home";
import Dashboard from "./components/dashboard";
import UpdateCandidate from "./components/updatecandidate";
import AddCandidate from "./components/addcandidate";

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[#05070a]">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/update-candidate" element={<UpdateCandidate />} />
          <Route path="/add-candidate" element={<AddCandidate />} />
          {/* Add other routes as they get implemented */}
          <Route path="*" element={<Home />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
