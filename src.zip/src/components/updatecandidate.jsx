import { useState, useMemo, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  FiArrowLeft, FiSave, FiUser, FiMail, FiPhone, 
  FiMessageCircle, FiBookOpen, FiUserCheck, FiTarget, 
  FiLock, FiCheck, FiClock, FiX, FiChevronDown, FiAlertCircle
} from 'react-icons/fi';
import { updateCandidateLocally, pushToGoogleSheet } from '../services/syncService';

const StageStep = ({ icon: Icon, label, isActive, isCompleted }) => (
  <div className="flex flex-col items-center gap-3 relative z-10">
    <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center transition-all duration-500 ${
      isActive 
        ? 'bg-indigo-500/20 border-indigo-500 text-indigo-400 shadow-[0_0_20px_rgba(99,102,241,0.3)]' 
        : isCompleted
          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
          : 'bg-[#0d1117] border-white/10 text-zinc-600'
    }`}>
      <Icon size={20} />
    </div>
    <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${isActive ? 'text-zinc-200' : 'text-zinc-500'}`}>
      {label}
    </span>
  </div>
);

const UpdateCandidate = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const candidateId = queryParams.get('id');

  const [activeStage, setActiveStage] = useState('GD');
  const [candidate, setCandidate] = useState(null);
  const [saveStatus, setSaveStatus] = useState("");

  // Load candidate details
  useEffect(() => {
    const data = localStorage.getItem('walkin_candidates');
    if (data) {
      const candidates = JSON.parse(data);
      const found = candidates.find(c => String(c.ID) === candidateId);
      if (found) setCandidate(found);
    }
  }, [candidateId]);

  const handleUpdateField = (field, value) => {
    setCandidate(prev => {
      const updated = { ...prev, [field]: value };
      
      // Auto-advance logic: If the user selects "Selected", jump to the next stage after a brief delay
      if (value === 'Selected') {
        const currentStageIdx = stages.findIndex(s => s.field === field);
        if (currentStageIdx !== -1 && currentStageIdx < stages.length - 1) {
          // If we are currently viewing the stage we just selected, advance
          const nextStage = stages[currentStageIdx + 1];
          if (stages[currentStageIdx].id === activeStage) {
            setTimeout(() => {
              setActiveStage(nextStage.id);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }, 800); // Slightly longer for the visual 'Selected' state to sink in
          }
        }
      }
      return updated;
    });
  };

  const handleSave = async () => {
    if (!candidate) return;
    setSaveStatus("Saving...");
    try {
      // 1. Update Local Store
      updateCandidateLocally(candidate.ID, candidate);
      
      // 2. Sync to Google Sheets if Script URL exists
      const scriptUrl = localStorage.getItem('walkin_script_url');
      if (scriptUrl) {
        await pushToGoogleSheet(scriptUrl, candidate);
        setSaveStatus("Synced with Matrix!");
      } else {
        setSaveStatus("Saved Locally!");
      }

      setTimeout(() => setSaveStatus(""), 3000);
    } catch (err) {
      console.error(err);
      setSaveStatus("Sync Error!");
      setTimeout(() => setSaveStatus(""), 3000);
    }
  };
  
  const stages = useMemo(() => [
    { id: 'GD', label: 'GD', icon: FiMessageCircle, field: 'GD Status', prev: null },
    { id: 'Aptitude', label: 'Aptitude', icon: FiBookOpen, field: 'Aptitude Status', prev: 'GD Status' },
    { id: 'L1', label: 'L1', icon: FiUserCheck, field: 'L1(selected /Rejected)', prev: 'Aptitude Status' },
    { id: 'L2', label: 'L2', icon: FiTarget, field: 'L2(Selected /Rejected)', prev: 'L1(selected /Rejected)' },
    { id: 'HR', label: 'HR', icon: FiUser, field: 'HR Round Status', prev: 'L2(Selected /Rejected)' },
  ], []);

  const isStageLocked = (stage) => {
    if (!stage.prev) return false;
    return candidate[stage.prev] !== 'Selected';
  };

  const currentStageData = useMemo(() => stages.find(s => s.id === activeStage), [activeStage, stages]);
  const isCurrentLocked = isStageLocked(currentStageData);

  if (!candidate) {
    return (
      <div className="min-h-screen bg-[#05070a] text-white flex flex-col items-center justify-center p-8">
        <FiAlertCircle className="text-rose-500 text-5xl mb-6 opacity-20" />
        <h2 className="text-xl font-black uppercase tracking-[0.4em] text-zinc-500">Candidate Not Found</h2>
        <button onClick={() => navigate('/dashboard')} className="mt-8 text-indigo-400 font-bold uppercase text-[10px] tracking-widest hover:text-white transition-all underline underline-offset-8">Return to Dashboard</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#05070a] text-white p-4 md:p-8 font-sans">
      <div className="max-w-[1400px] mx-auto">
        {/* Header Bar */}
        <div className="flex items-center justify-between mb-10">
          <button 
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-zinc-500 hover:text-white transition-colors"
          >
            <FiArrowLeft /> Back to Dashboard
          </button>
          
          <h1 className="text-sm font-black uppercase tracking-[0.4em] text-zinc-400">Update Candidate Profile</h1>
          
          <div className="flex items-center gap-4">
            {saveStatus && <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest animate-pulse">{saveStatus}</span>}
            <button 
              onClick={handleSave}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-xl flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-indigo-500/20 active:scale-95"
            >
              <FiSave /> Save All
            </button>
          </div>
        </div>

        {/* Candidate Info Card */}
        <div className="bg-[#0d1117] border border-white/5 rounded-[32px] p-8 mb-8 flex items-center gap-8 group">
          <div className="w-20 h-20 rounded-[24px] bg-linear-to-br from-indigo-500 to-fuchsia-600 flex items-center justify-center text-3xl font-black shadow-2xl group-hover:rotate-6 transition-transform">
            {candidate.Name ? candidate.Name.charAt(0) : "U"}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-4 mb-2">
              <h2 className="text-3xl font-black tracking-tight">{candidate.Name || "Unknown Candidate"}</h2>
              <span className="text-[10px] font-black bg-white/5 text-zinc-500 px-3 py-1 rounded-lg uppercase tracking-widest border border-white/5">ID: {candidate.ID}</span>
            </div>
            <div className="flex items-center gap-6 text-zinc-500 font-bold text-xs tracking-wide">
              <span className="flex items-center gap-2"><FiUser className="text-indigo-400" /> {candidate['Role Applied For?'] || "Not Specified"}</span>
              <span className="flex items-center gap-2"><FiMail className="text-indigo-400" /> {candidate['Email Address'] || "No Email"}</span>
              <span className="flex items-center gap-2"><FiPhone className="text-indigo-400" /> {candidate['Phone Number'] || "No Phone"}</span>
            </div>
          </div>
        </div>

        {/* Neural Stepper */}
        <div className="mb-12 relative px-20">
          <div className="absolute left-40 right-40 top-6 h-px bg-white/5 z-0" />
          <div className="flex items-center justify-between max-w-5xl mx-auto">
            {stages.map((stage, i) => {
              const locked = isStageLocked(stage);
              return (
                <button 
                  key={stage.id} 
                  onClick={() => !locked && setActiveStage(stage.id)}
                  disabled={locked}
                  className={locked ? 'cursor-not-allowed' : ''}
                >
                  <StageStep 
                    icon={locked ? FiLock : stage.icon} 
                    label={stage.label} 
                    isActive={stage.id === activeStage}
                    isCompleted={candidate[stage.field] === 'Selected'}
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* Overall Status Banner */}
        {/* Overall Status Banner */}
        <div className="bg-orange-500/5 border border-orange-500/10 rounded-2xl p-6 mb-8 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4">
            <span className="text-[8px] font-black uppercase tracking-[0.3em] text-orange-500/40">AUTOMATED</span>
          </div>
          <div className="flex items-start gap-5">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${candidate['HR Round Status'] === 'Selected' ? 'bg-emerald-500/10' : 'bg-orange-500/10'}`}>
              {candidate['HR Round Status'] === 'Selected' ? <FiCheckCircle className="text-emerald-500 text-xl" /> : <FiClock className="text-orange-500 text-xl" />}
            </div>
            <div>
              <h4 className={`font-black tracking-widest text-sm mb-1 uppercase ${candidate['HR Round Status'] === 'Selected' ? 'text-emerald-500' : 'text-orange-500'}`}>
                {candidate['HR Round Status'] || "Pending"}
              </h4>
              <p className={`text-xs font-bold leading-relaxed ${candidate['HR Round Status'] === 'Selected' ? 'text-emerald-500/60' : 'text-orange-500/60'}`}>
                {candidate['HR Round Status'] === 'Selected' ? 'Candidate hiring process completed successfully.' : 'Interview process is still in progress.'}
              </p>
            </div>
          </div>
        </div>

        {/* Active Stage Detail */}
        <div className={`bg-[#090b10] border-2 rounded-[32px] p-10 mb-6 relative overflow-hidden transition-all duration-500 ${isCurrentLocked ? 'border-white/5 opacity-50 grayscale' : 'border-indigo-500/30'}`}>
          <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.5)]" />
          
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-5 transition-transform">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center">
                {isCurrentLocked ? <FiLock className="text-zinc-600 text-2xl" /> : (
                  <>
                    {activeStage === 'GD' && <FiMessageCircle className="text-indigo-400 text-2xl" />}
                    {activeStage === 'Aptitude' && <FiBookOpen className="text-indigo-400 text-2xl" />}
                    {activeStage === 'L1' && <FiUserCheck className="text-indigo-400 text-2xl" />}
                    {activeStage === 'L2' && <FiTarget className="text-indigo-400 text-2xl" />}
                    {activeStage === 'HR' && <FiUser className="text-indigo-400 text-2xl" />}
                  </>
                )}
              </div>
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-400 mb-1">
                  STEP {stages.findIndex(s => s.id === activeStage) + 1}
                </p>
                <div className="flex items-center gap-3">
                  <h3 className="text-2xl font-black tracking-tight capitalize">{activeStage.replace(/([A-Z])/g, ' $1').trim()}</h3>
                  {isCurrentLocked && <span className="bg-white/5 text-[8px] px-2 py-0.5 rounded text-zinc-500 font-black tracking-widest uppercase">Locked Stage</span>}
                </div>
              </div>
            </div>
            
            {!isCurrentLocked && (
              <div className={`flex items-center gap-3 px-4 py-2 border rounded-xl transition-all ${
                candidate[stages.find(s => s.id === activeStage).field] === 'Selected'
                  ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-500'
                  : candidate[stages.find(s => s.id === activeStage).field] === 'Rejected'
                    ? 'bg-rose-500/5 border-rose-500/20 text-rose-500'
                    : 'bg-orange-500/5 border-orange-500/20 text-orange-500'
              }`}>
                <div className={`w-1.5 h-1.5 rounded-full animate-pulse bg-current`} />
                <span className="text-[10px] font-black tracking-[0.2em] uppercase">
                  {candidate[stages.find(s => s.id === activeStage).field] || "Pending"}
                </span>
              </div>
            )}
          </div>

          <div className={isCurrentLocked ? 'pointer-events-none' : ''}>
            {/* Form Grid */}
            {/* Form Grid */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-8">
              <div className="md:col-span-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-zinc-500 block mb-3">
                  {activeStage === 'Aptitude' ? 'Aptitude Marks' : 'Round Score'}
                </label>
                <input 
                  type="text"
                  disabled={isCurrentLocked}
                  value={candidate[activeStage === 'Aptitude' ? 'Aptitude Marks' : (activeStage === 'GD' ? 'GD Score' : 'Score')] || ""}
                  onChange={(e) => handleUpdateField(activeStage === 'Aptitude' ? 'Aptitude Marks' : (activeStage === 'GD' ? 'GD Score' : 'Score'), e.target.value)}
                  className="w-full bg-[#0d1117] border border-white/5 rounded-xl h-14 flex items-center justify-center text-zinc-300 font-black text-xl text-center outline-none focus:border-indigo-500/30 transition-all placeholder:text-zinc-800 disabled:opacity-30"
                  placeholder="—"
                />
              </div>
              
              <div className={activeStage === 'Aptitude' ? 'md:col-span-3' : 'md:col-span-4'}>
                <label className="text-[9px] font-black uppercase tracking-widest text-zinc-500 block mb-3">
                  {activeStage === 'Aptitude' ? 'Aptitude SET' : 'Interviewer Name'}
                </label>
                <div className="relative group">
                  {activeStage === 'Aptitude' ? (
                    <input 
                      type="text"
                      disabled={isCurrentLocked}
                      value={candidate['Aptitude SET'] || ""}
                      onChange={(e) => handleUpdateField('Aptitude SET', e.target.value)}
                      placeholder="SET A/B..."
                      className="w-full bg-[#0d1117] border border-white/10 rounded-xl h-14 px-5 text-sm font-bold text-zinc-300 outline-none focus:border-indigo-500/30 transition-all disabled:opacity-30"
                    />
                  ) : (
                    <>
                      <FiUser className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600 group-hover:text-indigo-400 transition-colors" />
                      <input 
                        type="text"
                        disabled={isCurrentLocked}
                        value={candidate[activeStage === 'L1' ? 'L1 Interviewer Name' : (activeStage === 'L2' ? 'L2 Interviewer Name' : 'Interviewer Name')] || ""}
                        onChange={(e) => handleUpdateField(activeStage === 'L1' ? 'L1 Interviewer Name' : (activeStage === 'L2' ? 'L2 Interviewer Name' : 'Interviewer Name'), e.target.value)}
                        placeholder="Enter Name..."
                        className="w-full bg-[#0d1117] border border-white/10 rounded-xl h-14 pl-14 pr-5 text-sm font-bold text-zinc-300 outline-none focus:border-indigo-500/30 transition-all disabled:opacity-30"
                      />
                    </>
                  )}
                </div>
              </div>

              <div className={activeStage === 'Aptitude' ? 'md:col-span-7' : 'md:col-span-6'}>
                <label className="text-[9px] font-black uppercase tracking-widest text-zinc-500 block mb-3">Status</label>
                <div className="grid grid-cols-3 gap-3">
                  <button 
                    disabled={isCurrentLocked}
                    onClick={() => handleUpdateField(currentStageData.field, 'Selected')}
                    className={`h-14 rounded-xl border flex items-center justify-center gap-2 text-[10px] font-black tracking-widest uppercase transition-all whitespace-nowrap px-4 ${
                      candidate[currentStageData.field] === 'Selected'
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.2)]'
                        : 'border-white/5 bg-[#0d1117] text-zinc-500 hover:bg-emerald-500/5 hover:border-emerald-500/30 hover:text-emerald-400'
                    }`}
                  >
                    <FiCheck /> Selected
                  </button>
                  <button 
                    disabled={isCurrentLocked}
                    onClick={() => handleUpdateField(currentStageData.field, 'Pending')}
                    className={`h-14 rounded-xl border flex items-center justify-center gap-2 text-[10px] font-black tracking-widest uppercase transition-all whitespace-nowrap px-4 ${
                      candidate[currentStageData.field] === 'Pending' || !candidate[currentStageData.field]
                        ? 'bg-orange-500/20 border-orange-500 text-orange-400 shadow-[0_0_20px_rgba(249,115,22,0.2)]'
                        : 'border-white/5 bg-[#0d1117] text-zinc-500 hover:bg-orange-500/5 hover:border-orange-500/30 hover:text-orange-400'
                    }`}
                  >
                    <FiClock /> Pending
                  </button>
                  <button 
                    disabled={isCurrentLocked}
                    onClick={() => handleUpdateField(currentStageData.field, 'Rejected')}
                    className={`h-14 rounded-xl border flex items-center justify-center gap-2 text-[10px] font-black tracking-widest uppercase transition-all whitespace-nowrap px-4 ${
                      candidate[currentStageData.field] === 'Rejected'
                        ? 'bg-rose-500/20 border-rose-500 text-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.2)]'
                        : 'border-white/5 bg-[#0d1117] text-zinc-500 hover:bg-rose-500/5 hover:border-rose-500/30 hover:text-rose-400'
                    }`}
                  >
                    <FiX /> Rejected
                  </button>
                </div>
              </div>
            </div>

          <div>
            <label className="text-[9px] font-black uppercase tracking-widest text-zinc-500 block mb-3">Interviewer Comments</label>
            <textarea 
              disabled={isCurrentLocked}
              value={candidate[activeStage === 'L1' ? 'L1 Comments' : (activeStage === 'L2' ? 'L2Comments' : 'Comments')] || ""}
              onChange={(e) => handleUpdateField(activeStage === 'L1' ? 'L1 Comments' : (activeStage === 'L2' ? 'L2Comments' : 'Comments'), e.target.value)}
              placeholder={isCurrentLocked ? "Stage is locked..." : `Add comments for ${activeStage.replace(/([A-Z])/g, ' $1').trim()}...`}
              className="w-full bg-[#0d1117] border border-white/5 rounded-2xl p-6 h-32 outline-none focus:border-indigo-500/30 text-sm font-medium text-zinc-300 placeholder:text-zinc-600 transition-all resize-none shadow-inner disabled:opacity-30"
            />
          </div>
          </div>

          {isCurrentLocked && (
            <div className="absolute inset-0 bg-[#05070a]/40 backdrop-blur-[2px] flex items-center justify-center z-20">
              <div className="bg-[#0d1117] border border-white/10 p-6 rounded-3xl flex flex-col items-center gap-4 shadow-2xl">
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center">
                  <FiLock className="text-zinc-500 text-xl" />
                </div>
                <div className="text-center">
                  <h4 className="text-sm font-black uppercase tracking-widest text-zinc-100 mb-1">Round Locked</h4>
                  <p className="text-xs font-bold text-zinc-500 max-w-[200px]">Complete the previous round to unlock this panel.</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Locked Next Stage Instruction */}
        {activeStage !== 'HR' && isStageLocked(stages[stages.findIndex(s => s.id === activeStage) + 1]) && (
          <div className="bg-[#0d1117]/30 border border-white/3 rounded-[32px] p-10 flex items-center gap-6 opacity-30 cursor-not-allowed grayscale mt-6">
            <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center">
              <FiLock className="text-zinc-600" />
            </div>
            <p className="text-sm font-bold text-zinc-500 tracking-wide">
              {stages[stages.findIndex(s => s.id === activeStage) + 1].label} will unlock when you mark {activeStage} as <span className="text-emerald-500/80">Selected</span>
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default UpdateCandidate;
