import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FiArrowLeft, FiPlus, FiDatabase, FiLink, FiCheckCircle, 
  FiRefreshCw, FiTrash2, FiSettings, FiExternalLink, FiFileText, FiAlertCircle
} from 'react-icons/fi';
import { syncCandidates } from '../services/syncService';

const SourceCard = ({ url, isSyncing, onRemove, onSync, lastSynced, syncError }) => (
  <div className="bg-[#0d1117] border border-white/5 rounded-2xl p-6 flex flex-col gap-4 group hover:border-white/10 transition-all">
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
          <FiFileText className="text-emerald-400 text-xl" />
        </div>
        <div>
          <h4 className="text-sm font-bold text-white">Google Spreadsheet</h4>
          <p className="text-[10px] text-zinc-500 font-bold tracking-wide mt-0.5">Primary Candidate Source</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button 
          onClick={onSync}
          disabled={isSyncing}
          className={`p-2.5 rounded-lg bg-white/5 text-zinc-400 hover:text-emerald-400 hover:bg-emerald-400/10 transition-all ${isSyncing ? 'animate-spin text-emerald-400' : ''}`}
        >
          <FiRefreshCw size={16} />
        </button>
        <button 
          onClick={onRemove}
          className="p-2.5 rounded-lg bg-white/5 text-zinc-400 hover:text-rose-400 hover:bg-rose-400/10 transition-all"
        >
          <FiTrash2 size={16} />
        </button>
      </div>
    </div>
    
    <div className="bg-black/20 rounded-xl p-4 flex items-center justify-between group/link border border-white/5">
      <div className="flex items-center gap-3 overflow-hidden">
        <FiLink className="text-zinc-600 shrink-0" />
        <span className="text-[10px] text-zinc-500 truncate font-medium">{url || "No link provided"}</span>
      </div>
      <a href={url} target="_blank" rel="noreferrer" className="text-zinc-600 hover:text-indigo-400 transition-colors">
        <FiExternalLink size={14} />
      </a>
    </div>

    <div className="flex items-center justify-between mt-2 pt-4 border-t border-white/5">
      <div className="flex items-center gap-2">
        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
        <span className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Connected</span>
      </div>
      <span className="text-[9px] font-black uppercase tracking-widest text-zinc-600">Last Synced: {lastSynced}</span>
    </div>
    {syncError && (
      <div className="flex items-center gap-2 text-rose-400 text-xs mt-2 bg-rose-400/5 p-3 rounded-lg border border-rose-400/10">
        <FiAlertCircle size={14} className="shrink-0" />
        <span className="font-bold uppercase tracking-tight text-[10px]">{syncError}</span>
      </div>
    )}
  </div>
);

const AddCandidate = () => {
  const navigate = useNavigate();
  const [sheetUrl, setSheetUrl] = useState(localStorage.getItem('walkin_sheet_url') || "");
  const [scriptUrl, setScriptUrl] = useState(localStorage.getItem('walkin_script_url') || "");
  const [sources, setSources] = useState(localStorage.getItem('walkin_sheet_url') ? [{ id: Date.now(), url: localStorage.getItem('walkin_sheet_url') }] : []);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncError, setSyncError] = useState("");
  const [lastSynced, setLastSynced] = useState(localStorage.getItem('walkin_last_sync') || "Never");

  const handleAddSource = async () => {
    if (sheetUrl && sheetUrl.includes('google.com/spreadsheets')) {
      setSyncError("");
      setIsSyncing(true);
      try {
        await syncCandidates(sheetUrl);
        setSources([{ id: Date.now(), url: sheetUrl }]);
        const time = new Date().toLocaleTimeString();
        setLastSynced(time);
        localStorage.setItem('walkin_sheet_url', sheetUrl);
        localStorage.setItem('walkin_last_sync', time);
        if (scriptUrl) localStorage.setItem('walkin_script_url', scriptUrl);
        // setSheetUrl(""); // Keep it visible for reference
      } catch (error) {
        console.error("Sync failed:", error);
        setSyncError("Failed to fetch data. Make sure the Google Sheet is 'Published to the Web' or public.");
      } finally {
        setIsSyncing(false);
      }
    } else {
      setSyncError("Invalid Google Sheets URL.");
    }
  };

  const handleSyncCurrent = async (url) => {
    setIsSyncing(true);
    setSyncError("");
    try {
      await syncCandidates(url);
      const time = new Date().toLocaleTimeString();
      setLastSynced(time);
      localStorage.setItem('walkin_last_sync', time);
    } catch (error) {
      console.error("Sync failed:", error);
      setSyncError("Sync failed. Check connection and ensure sheet is public.");
    } finally {
      setIsSyncing(false);
    }
  };

  const handleRemove = () => {
    localStorage.removeItem('walkin_sheet_url');
    localStorage.removeItem('walkin_script_url');
    localStorage.removeItem('walkin_candidates');
    localStorage.removeItem('walkin_last_sync');
    setSources([]);
    setSheetUrl("");
    setScriptUrl("");
    setLastSynced("Never");
    setSyncError("");
  };

  return (
    <div className="min-h-screen bg-[#05070a] text-white p-4 md:p-8 font-sans">
      <div className="max-w-[1200px] mx-auto">
        {/* Top Header */}
        <div className="flex items-center justify-between mb-12">
          <button 
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-zinc-500 hover:text-white transition-colors"
          >
            <FiArrowLeft /> Back to Portal
          </button>
          
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center shrink-0">
              <FiSettings className="text-indigo-400" />
            </div>
            <h1 className="text-sm font-black uppercase tracking-[0.4em] text-zinc-400 underline decoration-indigo-500/30 underline-offset-8">System Integration</h1>
          </div>
          
          <div className="w-[100px]" /> {/* Spacer */}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Configuration Side */}
          <div className="lg:col-span-5">
            <h2 className="text-3xl font-[1000] tracking-tighter mb-4">Connect Data <span className="text-transparent bg-clip-text bg-linear-to-r from-indigo-400 to-fuchsia-400">Sources</span></h2>
            <p className="text-zinc-500 text-sm font-medium leading-relaxed mb-10">
              Paste your Google Spreadsheet and Sync Script URLs below to enable bidirectional recruitment tracking.
            </p>

            <div className="bg-[#0d1117] border border-white/5 rounded-[32px] p-8 shadow-2xl">
              <div className="mb-6">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 block mb-3">Google Sheet URL (Read)</label>
                <div className="relative group">
                  <FiLink className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-indigo-400 transition-colors" />
                  <input 
                    type="text" 
                    placeholder="https://docs.google.com/spreadsheets/d/..."
                    value={sheetUrl}
                    onChange={(e) => setSheetUrl(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-4 pl-14 pr-6 text-sm outline-none focus:border-indigo-500/50 transition-all font-medium text-zinc-300 placeholder:text-zinc-700"
                  />
                </div>
              </div>

              <div className="mb-8">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 block mb-3">Sync Script URL (Write)</label>
                <div className="relative group">
                  <FiRefreshCw className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-fuchsia-400 transition-colors" />
                  <input 
                    type="text" 
                    placeholder="https://script.google.com/macros/s/.../exec"
                    value={scriptUrl}
                    onChange={(e) => setScriptUrl(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-4 pl-14 pr-6 text-sm outline-none focus:border-fuchsia-500/50 transition-all font-medium text-zinc-300 placeholder:text-zinc-700"
                  />
                </div>
                <p className="text-[9px] text-zinc-600 font-bold mt-2 px-1">Deploy your Apps Script as a Web App to enable saving changes back to Excel.</p>
              </div>

              <button 
                onClick={handleAddSource}
                disabled={!sheetUrl}
                className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white h-16 rounded-[20px] flex items-center justify-center gap-3 text-xs font-black uppercase tracking-[0.2em] transition-all shadow-xl shadow-indigo-500/20 active:scale-95"
              >
                <FiPlus size={18} /> Update Integration
              </button>
            </div>

            {/* Column Mapping Legend */}
            <div className="mt-12 p-8 bg-black/20 border border-white/5 rounded-[32px]">
              <h3 className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-6 flex items-center gap-3">
                <FiDatabase className="text-indigo-400" /> Primary Data Columns
              </h3>
              <div className="grid grid-cols-2 gap-y-3">
                {[
                  "ID", "Timestamp", "Name", "Email Address", "Phone Number", 
                  "Home Town", "Gender", "Role Applied For?", "Confirmation Mail?", 
                  "Work Experience?", "Experience Duration"
                ].map((col, i) => (
                  <div key={i} className="flex items-center gap-2 group">
                    <div className="w-1.5 h-1.5 rounded-full bg-zinc-700 group-hover:bg-indigo-500 transition-colors" />
                    <span className="text-[10px] text-zinc-500 group-hover:text-zinc-300 transition-colors font-bold uppercase tracking-wider">{col}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Active Sources Side */}
          <div className="lg:col-span-7">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-black tracking-tight">Active Connections</h3>
              <span className="bg-white/5 border border-white/10 px-3 py-1 rounded-lg text-[10px] font-black text-zinc-500 uppercase">{sources.length}</span>
            </div>

            {sources.length === 0 ? (
              <div className="h-[400px] border-2 border-dashed border-white/5 rounded-[40px] flex flex-col items-center justify-center bg-white/1">
                <div className="w-20 h-20 rounded-full bg-linear-to-b from-indigo-500/10 to-transparent flex items-center justify-center mb-6">
                  <FiDatabase className="text-zinc-700 text-3xl" />
                </div>
                <p className="text-zinc-600 text-sm font-bold tracking-tight uppercase">No active connections found</p>
                <p className="text-zinc-700 text-xs mt-2">Add a Google Sheet URL to manage data</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {sources.map(source => (
                  <SourceCard 
                    key={source.id} 
                    url={source.url} 
                    isSyncing={isSyncing}
                    onRemove={handleRemove}
                    onSync={() => handleSyncCurrent(source.url)}
                    lastSynced={lastSynced}
                    syncError={syncError}
                  />
                ))}
                
                <div className="p-8 bg-emerald-500/5 border border-emerald-500/10 rounded-[32px] flex items-start gap-6">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center shrink-0">
                    <FiCheckCircle className="text-emerald-500 text-2xl" />
                  </div>
                  <div>
                    <h4 className="text-emerald-500 font-black tracking-[0.2em] text-[10px] mb-2 uppercase">Sync Status</h4>
                    <p className="text-emerald-500/60 text-xs font-bold leading-relaxed">
                      System is ready to update metadata for GD Status, Aptitude SET, L1/L2 Interviews using the <b>ID</b> primary key.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddCandidate;
