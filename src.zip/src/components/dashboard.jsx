import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FiSearch, FiCalendar, FiMapPin, FiUsers, FiCheckCircle, 
  FiXCircle, FiClock, FiMessageCircle, FiBookOpen, 
  FiUserCheck, FiTarget, FiChevronRight, FiArrowLeft, FiEdit3, FiLayout
} from 'react-icons/fi';

const KPICard = ({ icon: Icon, label, value, colorClass, borderClass }) => (
  <div className={`bg-[#0d1117] border-l-2 ${borderClass} border-t border-r border-b border-white/5 p-4 py-3 rounded-xl flex items-center gap-4 group hover:bg-[#12161d] transition-all duration-300 relative overflow-hidden`}>
    <div className={`p-2.5 rounded-lg bg-opacity-10 ${colorClass} bg-current shrink-0`}>
      <Icon className={`w-5 h-5`} />
    </div>
    <div className="min-w-0 flex-1">
      <p className="text-[9px] font-black uppercase tracking-widest text-zinc-500 truncate leading-none mb-1">{label}</p>
      <h3 className="text-xl font-black text-white leading-none">{value}</h3>
    </div>
    {/* Decorative Shadcn-style Icon Accent */}
    <Icon className={`absolute -right-2 -bottom-2 w-12 h-12 ${colorClass} opacity-[0.03] group-hover:opacity-10 transition-opacity duration-500 rotate-12`} />
  </div>
);

const PositionCard = ({ title, count, breakdown, isActive, onClick }) => (
  <div 
    onClick={onClick}
    className={`p-6 border-b border-white/5 last:border-0 hover:bg-white/5 transition-all cursor-pointer group relative ${isActive ? 'bg-indigo-500/5' : ''}`}
  >
    {isActive && <div className="absolute left-0 top-0 w-1 h-full bg-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.5)]" />}
    <div className="flex items-center justify-between mb-4">
      <div>
        <h4 className={`text-sm font-bold transition-colors ${isActive ? 'text-indigo-400' : 'text-white group-hover:text-indigo-400'}`}>{title}</h4>
        <p className="text-[10px] text-zinc-500 font-bold mt-0.5">{count} Total Candidates</p>
      </div>
      <FiChevronRight className={`transition-all ${isActive ? 'text-indigo-400 translate-x-1' : 'text-zinc-600 group-hover:text-indigo-400 group-hover:translate-x-1'}`} />
    </div>
    <div className="flex items-center gap-4">
      {breakdown.map((item, i) => (
        <div key={i} className={`flex items-center gap-1.5 transition-all ${isActive ? 'grayscale-0 opacity-100' : 'grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100'}`}>
          <item.icon className={`w-3 h-3 ${item.color}`} />
          <span className="text-[10px] text-zinc-400 font-bold">{item.val}</span>
        </div>
      ))}
    </div>
  </div>
);

const CandidateCard = ({ ID, name, position, isExp, status, currentStage, stages }) => {
  const navigate = useNavigate();
  return (
    <div className="bg-[#090b10] border border-white/5 rounded-2xl p-6 hover:border-white/10 transition-all">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-5">
          <div className="w-12 h-12 rounded-full bg-indigo-600 flex items-center justify-center font-black text-white shadow-lg shadow-indigo-500/20">
            {name.charAt(0)}
          </div>
          <div>
            <h4 className="text-lg font-bold text-white leading-tight">{name}</h4>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-[10px] font-black uppercase tracking-widest text-indigo-400">{position}</span>
              {isExp && <span className="bg-emerald-500/10 text-emerald-400 text-[8px] font-black px-2 py-0.5 rounded tracking-widest uppercase">EXP</span>}
            </div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-orange-500/5 border border-orange-500/20 rounded-lg">
            <div className="w-1 h-1 rounded-full bg-orange-500 animate-pulse" />
            <span className="text-[9px] font-black uppercase tracking-widest text-orange-500">{status}</span>
          </div>
          <span className="text-[10px] font-black uppercase tracking-widest text-orange-500">{currentStage}</span>
          <button 
            onClick={() => navigate(`/update-candidate?id=${ID}`)}
            className="flex items-center gap-2 mt-2 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400 transition-all"
          >
            <FiEdit3 /> Update
          </button>
        </div>
      </div>

      {/* Stage Stepper */}
      <div className="flex items-center justify-between px-10 relative">
        <div className="absolute left-[50px] right-[50px] top-1/2 -translate-y-1/2 h-px bg-white/5 z-0" />
        {stages.map((stage, i) => (
          <div key={i} className="relative z-10 flex flex-col items-center gap-2">
            <div className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all ${
              stage.active ? `bg-${stage.color}-500/20 border-${stage.color}-500/50 text-${stage.color}-400 shadow-[0_0_15px_rgba(99,102,241,0.3)]` : 'bg-[#0d1117] border-white/10 text-zinc-600'
            }`}>
              <stage.icon size={14} />
            </div>
            <span className={`text-[8px] font-black uppercase tracking-widest ${stage.active ? 'text-zinc-300' : 'text-zinc-600'}`}>{stage.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const Dashboard = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRole, setSelectedRole] = useState(null);
  
  // Fetch real data from LocalStorage
  const candidatesRaw = useMemo(() => {
    const data = localStorage.getItem('walkin_candidates');
    return data ? JSON.parse(data) : [];
  }, []);

  // Sync state with sheet columns
  const candidates = useMemo(() => {
    return candidatesRaw.map(cand => ({
      ...cand,
      name: cand.Name || "Unknown",
      position: cand['Role Applied For?'] || "Not Specified",
      isExp: cand['Have a relevent work experience before?'] === 'Yes',
      status: cand['HR Round Status'] || "PENDING",
      currentStage: cand['GD Status'] === 'Selected' ? (cand['Aptitude Status'] === 'Selected' ? (cand['L1(selected /Rejected)'] === 'Selected' ? 'L2' : 'L1') : 'Aptitude') : 'GD',
      stages: [
        { label: "GD", icon: FiMessageCircle, color: "blue", active: cand['GD Status'] === 'Selected' },
        { label: "Aptitude", icon: FiBookOpen, color: "indigo", active: cand['Aptitude Status'] === 'Selected' },
        { label: "L1", icon: FiUserCheck, color: "amber", active: cand['L1(selected /Rejected)'] === 'Selected' },
        { label: "L2", icon: FiTarget, color: "emerald", active: cand['L2(Selected /Rejected)'] === 'Selected' }
      ]
    }));
  }, [candidatesRaw]);

  // Dynamic KPI Calculations
  const stats = useMemo(() => {
    const total = candidates.length;
    const selected = candidates.filter(c => c['HR Round Status'] === 'Selected').length;
    const rejected = candidates.filter(c => c['HR Round Status'] === 'Rejected').length;
    const pending = total - selected - rejected;
    
    const gdSelected = candidates.filter(c => c['GD Status'] === 'Selected').length;
    const aptSelected = candidates.filter(c => c['Aptitude Status'] === 'Selected').length;
    const l1Selected = candidates.filter(c => c['L1(selected /Rejected)'] === 'Selected').length;
    const l2Selected = candidates.filter(c => c['L2(Selected /Rejected)'] === 'Selected').length;
    
    return { total, selected, rejected, pending, gdSelected, aptSelected, l1Selected, l2Selected };
  }, [candidates]);

  // Extract unique positions
  const positions = useMemo(() => {
    const posMap = {};
    candidates.forEach(c => {
      const p = c.position;
      if (!posMap[p]) posMap[p] = { title: p, count: 0, breakdown: [] };
      posMap[p].count++;
    });
    return Object.values(posMap);
  }, [candidates]);

  const filteredCandidates = candidates.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         c.position.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = selectedRole ? c.position === selectedRole : true;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="min-h-screen bg-[#05070a] text-white p-4 md:p-8 font-sans">
      {/* Top Bar */}
      <div className="max-w-[1600px] mx-auto">
        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-zinc-500 hover:text-white transition-colors mb-6"
        >
          <FiArrowLeft /> Back to Portal
        </button>

        {/* Header Section */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-8">
          <div className="flex items-center gap-6">
            <div className="w-14 h-14 bg-linear-to-br from-indigo-500 to-fuchsia-600 rounded-[20px] flex items-center justify-center shadow-2xl shadow-indigo-500/20">
              <FiLayout className="text-white text-2xl" />
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tight leading-tight">Walk-in Interview Management</h1>
              <p className="text-xs text-zinc-500 font-bold tracking-wide mt-1">Real-time candidate tracking & interview pipeline</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative group">
              <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 group-focus-within:text-indigo-400 transition-colors" />
              <input 
                type="text" 
                placeholder="Search candidates..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-[#0d1117] border border-white/10 rounded-xl py-3 pl-12 pr-6 text-sm outline-none focus:border-indigo-500/50 w-full sm:w-64 transition-all"
              />
            </div>
            <button className="bg-[#0d1117] border border-white/10 rounded-xl px-5 py-3 flex items-center gap-3 text-xs font-bold text-zinc-400 hover:border-white/20 transition-all">
              <FiCalendar /> All Dates
            </button>
            <button className="bg-[#0d1117] border border-white/10 rounded-xl px-5 py-3 flex items-center gap-3 text-xs font-bold text-zinc-400 hover:border-white/20 transition-all">
              <FiMapPin /> All Branches
            </button>
          </div>
        </div>

        {/* KPI Grid - Horizontal Design */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4 mb-4">
          <KPICard icon={FiUsers} label="Total Candidates" value={stats.total} colorClass="text-indigo-400" borderClass="border-indigo-500/50" />
          <KPICard icon={FiCheckCircle} label="Selected" value={stats.selected} colorClass="text-emerald-400" borderClass="border-emerald-500/50" />
          <KPICard icon={FiXCircle} label="Rejected" value={stats.rejected} colorClass="text-rose-400" borderClass="border-rose-500/50" />
          <KPICard icon={FiClock} label="Pending" value={stats.pending} colorClass="text-amber-400" borderClass="border-amber-500/50" />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4 mb-8">
          <KPICard icon={FiMessageCircle} label="GD Selected" value={stats.gdSelected} colorClass="text-blue-400" borderClass="border-blue-500/50" />
          <KPICard icon={FiBookOpen} label="Aptitude Selected" value={stats.aptSelected} colorClass="text-indigo-400" borderClass="border-indigo-500/50" />
          <KPICard icon={FiUserCheck} label="L1 Selected" value={stats.l1Selected} colorClass="text-amber-400" borderClass="border-amber-500/50" />
          <KPICard icon={FiTarget} label="L2 Selected" value={stats.l2Selected} colorClass="text-emerald-400" borderClass="border-emerald-500/50" />
        </div>

        {/* Main Sections */}
        <div className="grid grid-cols-1 xl:grid-cols-[400px_1fr] gap-8 h-full min-h-0">
          {/* Open Positions */}
          <section className="bg-[#0d1117]/50 border border-white/5 rounded-[32px] overflow-hidden flex flex-col h-fit max-h-[700px]">
            <div className="p-8 pb-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FiTarget className="text-indigo-400 text-xl" />
                <h3 className="text-xl font-black tracking-tight">Open Positions</h3>
              </div>
              <span className="bg-indigo-500/10 text-indigo-400 text-[10px] font-black px-2 py-0.5 rounded">{positions.length}</span>
            </div>
            <div className="flex-1 overflow-y-auto scrollbar-thin">
              {positions.map((pos, i) => (
                <PositionCard 
                  key={i} 
                  {...pos} 
                  isActive={selectedRole === pos.title}
                  onClick={() => setSelectedRole(selectedRole === pos.title ? null : pos.title)}
                />
              ))}
            </div>
          </section>

          {/* Candidates List - Dynamic Stream */}
          <section className="bg-[#0d1117]/50 border border-white/5 rounded-[32px] overflow-hidden flex flex-col h-[700px]">
            <div className="p-8 pb-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FiUsers className="text-indigo-400 text-xl" />
                <h3 className="text-xl font-black tracking-tight">
                  {selectedRole ? `Candidates: ${selectedRole}` : "All Candidates"}
                </h3>
              </div>
              <div className="flex items-center gap-3">
                {selectedRole && (
                  <button 
                    onClick={() => setSelectedRole(null)}
                    className="text-[9px] font-black uppercase tracking-widest text-zinc-500 hover:text-white transition-colors"
                  >
                    Clear Filter
                  </button>
                )}
                <span className="bg-indigo-500/10 text-indigo-400 text-[10px] font-black px-2 py-0.5 rounded">{filteredCandidates.length}</span>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-8 pt-2 space-y-4 scrollbar-thin">
              {filteredCandidates.map((cand, i) => (
                <CandidateCard key={i} {...cand} />
              ))}
              {filteredCandidates.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center opacity-20 py-20">
                  <FiUsers size={48} />
                  <p className="mt-4 font-black uppercase tracking-widest text-xs">No Candidates Found</p>
                </div>
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
