import { Link } from 'react-router-dom';
import { FiLayout, FiGlobe, FiCpu, FiEdit3, FiShare2 } from 'react-icons/fi';

const FeatureCard = ({ title, description, icon: Icon, iconBg, dotColor, link }) => {
  return (
    <Link to={link} className="group relative bg-[#090b10]/60 backdrop-blur-2xl border border-white/5 rounded-[40px] p-10 transition-all duration-700 hover:bg-white/2 hover:border-white/10 hover:translate-y-[-12px] hover:shadow-[0_40px_80px_-30px_rgba(0,0,0,0.8)] flex flex-col h-full overflow-hidden">
      {/* Icon Section */}
      <div className={`w-16 h-16 rounded-[22px] flex items-center justify-center mb-12 relative overflow-hidden group-hover:scale-110 transition-transform duration-500`}>
        <div className={`absolute inset-0 opacity-20 ${iconBg}`} />
        <div className={`absolute inset-0 blur-xl opacity-30 ${iconBg}`} />
        <Icon className={`w-7 h-7 z-10 text-white`} />
      </div>

      {/* Content */}
      <div className="flex-1">
        <h3 className="text-[26px] font-bold text-white mb-5 tracking-tight group-hover:text-indigo-400 transition-colors duration-300">
          {title}
        </h3>
        <p className="text-zinc-500 text-[15px] leading-relaxed font-medium opacity-80">
          {description}
        </p>
      </div>

      {/* Decorative Accent Icon */}
      <div className={`absolute bottom-6 right-6 opacity-40 group-hover:opacity-100 transition-all duration-500 group-hover:scale-110 group-hover:rotate-12`}>
        <Icon className={`w-4 h-4 ${dotColor.replace('bg-', 'text-')}`} />
      </div>
    </Link>
  );
};

const Home = () => {
  const features = [
    {
      title: "Recruitment Dashboard",
      description: "Monitor live walk-in metrics, track candidate pipeline, and manage interview rounds in real-time.",
      icon: FiLayout,
      iconBg: "bg-blue-600",
      dotColor: "bg-blue-400",
      link: "/dashboard"
    },
    {
      title: "Add Candidate",
      description: "Connect external data sources (Google Form / Sheet) to automate candidate ingestion and synchronize walk-in data.",
      icon: FiGlobe,
      iconBg: "bg-emerald-600",
      dotColor: "bg-emerald-400",
      link: "/add-candidate"
    },
    {
      title: "Add Interviewer",
      description: "Onboard new technical panel members and map their expertise for efficient interview scheduling.",
      icon: FiCpu,
      iconBg: "bg-violet-600",
      dotColor: "bg-violet-400",
      link: "/add-interviewer"
    },
    {
      title: "Manage Candidates",
      description: "Search, filter, and modify existing candidate profiles to keep your recruitment data up-to-date.",
      icon: FiEdit3,
      iconBg: "bg-orange-600",
      dotColor: "bg-orange-400",
      link: "/manage"
    }
  ];

  return (
    <div className="min-h-screen w-full bg-[#05070a] text-white flex flex-col items-center justify-center px-6 py-12 relative overflow-hidden font-sans">
      {/* Background radial glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-[1400px] pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-indigo-500/10 rounded-full blur-[160px] opacity-40" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-fuchsia-500/10 rounded-full blur-[160px] opacity-30" />
      </div>

      {/* Badge */}
      <div className="z-10 bg-white/5 border border-white/10 px-6 py-3 rounded-full mb-16 flex items-center gap-4 backdrop-blur-xl shadow-[0_0_20px_rgba(0,0,0,0.5)]">
        <div className="relative flex items-center justify-center">
          <FiShare2 className="w-4 h-4 text-indigo-400 rotate-45" />
          <div className="absolute inset-0 blur-sm bg-indigo-500/40" />
        </div>
        <span className="text-[11px] font-black uppercase tracking-[0.3em] text-zinc-300">
          GWC DATA.AI WALK-IN PORTAL
        </span>
      </div>

      {/* Hero Section */}
      <div className="z-5 text-center max-w-[1100px] mb-20 px-4">
        <h1 className="text-[64px] md:text-[88px] font-[1000] mb-12 tracking-[-0.04em] leading-[1.05] text-white">
          Seamless <span className="text-transparent bg-clip-text bg-linear-to-r from-indigo-400 via-fuchsia-500 to-rose-400">Recruitment</span> Management <span className="inline-block">System</span>
        </h1>
        <p className="text-zinc-500 text-lg md:text-[22px] max-w-3xl mx-auto leading-relaxed font-medium opacity-70">
          Empower your HR team with a high-performance tool designed for high-volume walk-in recruitment drives. Track every interaction from Group Discussion to Final Offer.
        </p>
      </div>

      {/* Features Grid */}
      <div className="z-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-7 w-full max-w-7xl mx-auto px-4">
        {features.map((feature, index) => (
          <FeatureCard key={index} {...feature} />
        ))}
      </div>
    </div>
  );
};

export default Home;
